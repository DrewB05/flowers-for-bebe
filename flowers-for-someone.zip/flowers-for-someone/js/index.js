const title = document.querySelector('.title');
const text = 'HI BUBBA! I HAVE SPECIAL SUPRISE FOR U!'.split('');

for (let index = 0; index < text.length; index++) {
  if (text[index] !== ' ') {
    title.innerHTML += `<span>${text[index]}</span>`;
  } else {
    title.innerHTML += `<span style='margin-right: 20px;'></span>`;
  }
}

const textElements = document.querySelectorAll('.title span');
textElements.forEach((element) => {
  const randomDelay = Math.random() * 3; // Random delay between 0 and 3 seconds
  element.style.animationDelay = `${randomDelay}s`;
});

// Display the GIF after text animation
const gif = document.querySelector('.surprise-gif');
setTimeout(() => {
  gif.style.display = 'block'; // Show the GIF
  gif.style.opacity = 0; // Start with opacity 0
  gif.style.transition = 'opacity 1s'; // Fade-in effect
  gif.style.opacity = 1; // Set opacity to 1 to fade in
}, 3500); // Adjust delay if needed to sync with text animation
